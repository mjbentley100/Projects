/**
 * @file gl.c
 * @author Mason Bentley
 * @date 12/8/2017
 * Assignment: Game of life
 * @todo Impliment selected cordinate system
 * @brief This program models game of life
 * @details This program models gamae of life on three different game boards includeing the "hedge" the "torus" and the "klein" bottle. it also allows for several command line parameters, including color, size of board, type of board, and the size of the sprite.
 * @bugs 
 */

#include <stdlib.h>
#include "SDL2/SDL.h" 
#include "sdl.h"
#include "life.h"
#include <ctype.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[])
{
	int width = 800;
	int height = 600;
	int sprite_size = 4; /* either 2, 4, 8, or 16 */
	/*int m = -66;
	int n = -10;*/
	int c;
	char * filename = "glider_106.lif";
	char * edge_type = "hedge";
	char * hedge = "hedge";
	char * torus = "torus";
	char * klein = "klein";

	int sprite_height;
	int sprite_width;

	unsigned char ** array_1 = NULL;
	unsigned char ** array_2 = NULL;


        /* colors are RGB model valid values [0, 255] */
	unsigned char red = 140;
	unsigned char green = 145;
	unsigned char blue = 250;
        struct sdl_info_t sdl_info; /* this is needed to graphically display the game */
        
       	/*command line arguments*/
	while((c = getopt(argc, argv, "w:h:e:r:g:b:s:f:H")) != -1)
	{
		switch (c)
		{
			case 'w':
				width = atoi(optarg);
				break;
			case 'h':
				height = atoi(optarg);
				break;
			case 'e':
				edge_type = optarg;
				break;
			case 'r':
				red = atoi(optarg);
				break;
			case 'g':
				green = atoi(optarg);
				break;
			case 'b':
				blue = atoi(optarg);
				break;
			case 's':
				sprite_size = atoi(optarg);
				break;
			case 'f':
				filename = optarg;
				break;
			case 'H':
				printf("usage statement\n");
				printf("-w - width\n");
				printf("-h - height\n");
				printf("-e - edge type\n");
				printf("-r -g -b red green blue (0 - 255)\n");
				printf("-s - sprite size\n");
				printf("-f -  filename\n");
				printf("-H - brings up help menu... duh\n");
				break;
		}

	}
	
	/* set up SDL -- works with SDL2 */
	init_sdl_info(&sdl_info, width, height, sprite_size, red, green, blue);


	/*initalizations*/
	sprite_height = height / sprite_size;
	sprite_width = width / sprite_size;


	array_1 = init_matrix(sprite_width, sprite_height);
	array_1 = set_zero(array_1, sprite_width, sprite_height);
	array_1 = init(array_1, filename, sprite_width, sprite_height);

	array_2 = init_matrix(sprite_width, sprite_height);

	int i;
	

	for (i = 0; i < 40; i++) {
		sdl_render_life(&sdl_info, array_1);	
	}

        /* Main loop: loop forever. */
	while (1)
	{
		/* your game of life code goes here  */	
		if (strcmp(edge_type, hedge) == 0)	
		{
			array_2 = set_zero(array_2, sprite_width, sprite_height);
			array_2 = gen_next(array_1, array_2, sprite_width, sprite_height);
			sdl_render_life(&sdl_info, array_2);
		
			array_1 = set_zero(array_1, sprite_width, sprite_height);
			array_1 = gen_next(array_2, array_1, sprite_width, sprite_height);
			sdl_render_life(&sdl_info, array_1);

		} else if (strcmp(edge_type, torus) == 0) {

			array_2 = set_zero(array_2, sprite_width, sprite_height);
			array_2 = gen_next_torus(array_1, array_2, sprite_width, sprite_height);
			sdl_render_life(&sdl_info, array_2);
		
			array_1 = set_zero(array_1, sprite_width, sprite_height);
			array_1 = gen_next_torus(array_2, array_1, sprite_width, sprite_height);
			sdl_render_life(&sdl_info, array_1);

		} else if (strcmp(edge_type, klein) == 0) {

			array_2 = set_zero(array_2, sprite_width, sprite_height);
			array_2 = gen_next_klein(array_1, array_2, sprite_width, sprite_height);
			sdl_render_life(&sdl_info, array_2);
		
			array_1 = set_zero(array_1, sprite_width, sprite_height);
			array_1 = gen_next_klein(array_2, array_1, sprite_width, sprite_height);
			sdl_render_life(&sdl_info, array_1);
		}

		/* change the  modulus value to slow the rendering */
		/*if (SDL_GetTicks() % 100 == 0);*/

                 /* Poll for events, and handle the ones we care about. 
                  * You can click the X button to close the window
                  */
		SDL_Event event;
		while (SDL_PollEvent(&event)) 
		{
			switch (event.type) 
			{
			case SDL_KEYDOWN:
				break;
			case SDL_KEYUP:
                        /* If escape is pressed, return (and thus, quit) */
				if (event.key.keysym.sym == SDLK_ESCAPE)
					return 0;
				break;
			case SDL_QUIT:
				return(0);
			}
		}
	}
	free_grid(array_1);
	free_grid(array_2);
	return 0;
}





















