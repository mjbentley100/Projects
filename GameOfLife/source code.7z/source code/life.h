/**
 *@file life.h
 *@brief models the game of life
 *@author mason bentley
 *@date 12/8/2017
*/
#ifndef LIFE_H_
#define LIFE_H_
#include "sdl.h"
#include <ctype.h>
#include <unistd.h>

/*Definitions*/
unsigned char **init_matrix(int rows, int cols);
unsigned char **set_zero(unsigned char ** matrix, int rows, int cols);
unsigned char **gen_next(unsigned char ** matrix_1, unsigned char ** matrix_2, int rows, int cols);
int get_count(unsigned char ** matrix, int i, int j);
unsigned char **init(unsigned char ** matrix, char * filename, int rows, int cols);
unsigned char **gen_next_torus(unsigned char ** matrix_1, unsigned char ** matrix_2, int rows, int cols);
int get_count_torus(unsigned char ** matrix, int i, int j, int rows, int cols);
unsigned char **gen_next_klein(unsigned char ** matrix_1, unsigned char ** matrix_2, int rows, int cols);
int get_count_klein(unsigned char ** matrix, int i, int j, int rows, int cols);
void free_grid(unsigned char ** matrix);

#endif



