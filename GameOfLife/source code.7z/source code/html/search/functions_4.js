var searchData=
[
  ['sdl_5frender_5flife',['sdl_render_life',['../sdl_8h.html#afec672c5d4f9b0381339bd3229f28889',1,'sdl.h']]],
  ['sdl_5ftest',['sdl_test',['../sdl_8h.html#ada6b3150b36edb0a418e47d340006ea4',1,'sdl.h']]],
  ['set_5fzero',['set_zero',['../life_8c.html#a4ac47283b0b40abcab328b2230b2fe7b',1,'set_zero(unsigned char **matrix, int rows, int cols):&#160;life.c'],['../life_8h.html#a4ac47283b0b40abcab328b2230b2fe7b',1,'set_zero(unsigned char **matrix, int rows, int cols):&#160;life.c']]]
];
