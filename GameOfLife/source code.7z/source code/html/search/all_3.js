var searchData=
[
  ['gen_5fnext',['gen_next',['../life_8c.html#a3be50b3e1c1d43148cd4044ecf421d83',1,'gen_next(unsigned char **matrix_1, unsigned char **matrix_2, int rows, int cols):&#160;life.c'],['../life_8h.html#a3be50b3e1c1d43148cd4044ecf421d83',1,'gen_next(unsigned char **matrix_1, unsigned char **matrix_2, int rows, int cols):&#160;life.c']]],
  ['gen_5fnext_5fklein',['gen_next_klein',['../life_8c.html#af017bb61bb588465d1c13929c18ccb26',1,'gen_next_klein(unsigned char **matrix_1, unsigned char **matrix_2, int rows, int cols):&#160;life.c'],['../life_8h.html#af017bb61bb588465d1c13929c18ccb26',1,'gen_next_klein(unsigned char **matrix_1, unsigned char **matrix_2, int rows, int cols):&#160;life.c']]],
  ['gen_5fnext_5ftorus',['gen_next_torus',['../life_8c.html#aab30ea261c01cbb1bfb5f58230e818fb',1,'gen_next_torus(unsigned char **matrix_1, unsigned char **matrix_2, int rows, int cols):&#160;life.c'],['../life_8h.html#aab30ea261c01cbb1bfb5f58230e818fb',1,'gen_next_torus(unsigned char **matrix_1, unsigned char **matrix_2, int rows, int cols):&#160;life.c']]],
  ['get_5fcount',['get_count',['../life_8c.html#af91a0069306b7962803390871a4528e1',1,'get_count(unsigned char **matrix, int i, int j):&#160;life.c'],['../life_8h.html#af91a0069306b7962803390871a4528e1',1,'get_count(unsigned char **matrix, int i, int j):&#160;life.c']]],
  ['get_5fcount_5fklein',['get_count_klein',['../life_8c.html#aa0da9f48270728214a2b2668115f5acb',1,'get_count_klein(unsigned char **matrix, int i, int j, int rows, int cols):&#160;life.c'],['../life_8h.html#aa0da9f48270728214a2b2668115f5acb',1,'get_count_klein(unsigned char **matrix, int i, int j, int rows, int cols):&#160;life.c']]],
  ['get_5fcount_5ftorus',['get_count_torus',['../life_8c.html#a8aa50d04cc81d3bd6e1e0964cf070f23',1,'get_count_torus(unsigned char **matrix, int i, int j, int rows, int cols):&#160;life.c'],['../life_8h.html#a8aa50d04cc81d3bd6e1e0964cf070f23',1,'get_count_torus(unsigned char **matrix, int i, int j, int rows, int cols):&#160;life.c']]],
  ['getopt_5fexample_2ec',['getopt_example.c',['../getopt__example_8c.html',1,'']]],
  ['gl_2ec',['gl.c',['../gl_8c.html',1,'']]],
  ['green',['green',['../structcolor__t.html#a85e1636e41c5772cf432e4612ed00310',1,'color_t']]]
];
