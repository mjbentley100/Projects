var searchData=
[
  ['free_5fgrid',['free_grid',['../life_8c.html#ad34c6854c37c0c4c1a15b10f526340e0',1,'free_grid(unsigned char **matrix):&#160;life.c'],['../life_8h.html#ad34c6854c37c0c4c1a15b10f526340e0',1,'free_grid(unsigned char **matrix):&#160;life.c']]]
];
