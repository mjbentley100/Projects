var searchData=
[
  ['screen',['screen',['../structsdl__info__t.html#ace88dc90952d64264b8f8ceedc5f1847',1,'sdl_info_t']]],
  ['sprite_5fsize',['sprite_size',['../structsdl__info__t.html#ab25151bb7aded0b292222bcddb8314e1',1,'sdl_info_t']]]
];
