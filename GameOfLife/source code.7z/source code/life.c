/**
 * @file life.c
 * @author Mason Bentley
 * @date 12/8/2017
 * Assignment: Game of life
 * @todo Impliment selected cordinate system
 * @brief This program models game of life
 * @details This program models gamae of life on three different game boards includeing the "hedge" the "torus" and the "klein" bottle. it also allows for several command line parameters, including color, size of board, type of board, and the size of the sprite.
 * @bugs 
 */

#include "life.h"
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>


/*Definitions*/



/**
 * Initializes the game of life matrix
 * @param the number of rows
 * @param the number of columbs
 * @return the 2 dimensional array
 */
unsigned char **init_matrix(int rows, int cols)
{
	int i;
	int j;
	unsigned char **a;
	/* allocate rows */
	a = malloc(rows * sizeof(int *));
	if(!a)
		return NULL;
	for(i = 0; i < rows; i++) 
	{
		/* allocate cols for each row */
		a[i] = malloc(cols * sizeof(int));
		if (!a[i]) 
		{
			for (j = 0; j < i; j++)
				free(a[j]);
			free(a);
			return NULL;
		}
	}
	return a;
}

/**
 * Sets all values in a matrix to 0
 * @param the nummber of rows
 * @param the number of columbs
 * @return the new matrix
 */
unsigned char **set_zero(unsigned char **matrix, int rows, int cols)
{

	int i;
	int j;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < cols; j++)
		{
			matrix[i][j] = 0;
		}
	} 


	return matrix;
}

/**
 * Generates the next generation of cells in the series with the hedge board
 * @param the current generation (matrix)
 * @param the new generation (matrix)
 * @return the new matrix
 */
unsigned char **gen_next(unsigned char ** matrix_1, unsigned char ** matrix_2, int rows, int cols)
{
	int i;
	int j;
	int count = 0;

	for (i = 1; i < (rows - 1); i++)
		{
			for (j = 1; j < (cols - 1); j++)
			{
				count = get_count(matrix_1, i, j);
				if (matrix_1[i][j] == 0)
				{
					if (count == 3) 
					{
						matrix_2[i][j] = 1;
					}
				} else if (matrix_1[i][j] == 1) {
					if ((count < 2) || (count > 3))
					{
						matrix_2[i][j] = 0;
					} else if ((count == 3) || (count == 2)) {
						matrix_2[i][j] = 1;
					}
				}
			}
		}
	return matrix_2;
}

/**
 * Counts the number of alive cells next to a given cel
 * @param the current matrix
 * @param the x coordinate (i = the rows which is the x axis)
 * @param the y coordinate (j = the cols which is the y axis)
 * @return the amount of alive cells next to the given cell (i, j)
 */
int get_count(unsigned char ** matrix, int i, int j)
{
	int count = 0;
	int k;
	int l;

	for (k = (i - 1); k <= (i + 1); k++)
	{
		for (l = (j - 1); l <= (j + 1); l++) 
		{
			if (matrix[k][l] == 1)
			{
				count = count + 1;
			}
		}
	}

	if (matrix[i][j] == 1)
	{
		count = count - 1;
	}

	return count;
}


/**
 * Generates the next generation of cells in the series with the hedge board
 * @param the current generation (matrix)
 * @param the file name for the pattern to be initalized
 * @param the number of rows
 * @param the number of columbs
 * @return the new matrix
 */
unsigned char **init(unsigned char ** matrix, char * filename, int rows, int cols)
{
	
	FILE *in;
	char buf[1024];
	char * s = NULL;
	char * x_val = NULL;
	char * y_val = NULL;
	int x_cord = (rows / 2);
	int y_cord = (cols / 2);
	int x;
	int y;
	int i = 0;

	in = fopen(filename, "r");
	if (in == NULL)
	{
		printf("Error in opening file\n");
		return 0;
	}
	
	while (fgets(buf, 1024, in))
	{
		if (i == 0)
		{
			s = strtok(buf, "\n");
		} else {
		s = strtok(buf, " ");
		x_val = s;
		x = atoi(x_val);
		s = strtok(NULL, "\n");
		y_val = s;
		y = atoi(y_val);
		matrix[(x + x_cord)][(y + y_cord)] = 1;
		}
		i++;	
	}
		
	fclose(in);
	return matrix;
}


/**
 * Generates the next generation of cells in the series with the torus board
 * @param the current generation (matrix)
 * @param the new generation (matrix)
 * @return the new matrix
 */
unsigned char **gen_next_torus(unsigned char ** matrix_1, unsigned char ** matrix_2, int rows, int cols)
{
	int i;
	int j;
	int count = 0;

	for (i = 0; i < rows; i++)
		{
			for (j = 0; j < cols; j++)
			{
				count = get_count_torus(matrix_1, i, j, rows, cols);
				if (matrix_1[i][j] == 0)
				{
					if (count == 3) 
					{
						matrix_2[i][j] = 1;
					}
				} else if (matrix_1[i][j] == 1) {
					if ((count < 2) || (count > 3))
					{
						matrix_2[i][j] = 0;
					} else if ((count == 3) || (count == 2)) {
						matrix_2[i][j] = 1;
					}
				}
			}
		}
	return matrix_2;
}

/**
 * Counts the number of alive cells next to a given cell, for a torus board
 * @param the current matrix
 * @param the x coordinate (i = the rows which is the x axis)
 * @param the y coordinate (j = the cols which is the y axis)
 * @return the amount of alive cells next to the given cell (i, j)
 */
int get_count_torus(unsigned char ** matrix, int i, int j, int rows, int cols)
{
	int count = 0;
	int k;
	int l;

	for (k = (i - 1); k <= (i + 1); k++)
	{
		for (l = (j - 1); l <= (j + 1); l++) 
		{
			if (matrix[((k + rows) % rows)][((l + cols) % cols)] == 1) /*input %*/
			{
				count = count + 1;
			}
		}
	}

	if (matrix[i][j] == 1)
	{
		count = count - 1;
	}

	return count;
}



/**
 * Generates the next generation of cells in the series with the klein board
 * @param the current generation (matrix)
 * @param the new generation (matrix)
 * @return the new matrix
 */
unsigned char **gen_next_klein(unsigned char ** matrix_1, unsigned char ** matrix_2, int rows, int cols)
{
	int i;
	int j;
	int count = 0;

	for (i = 0; i < rows; i++)
		{
			for (j = 0; j < cols; j++)
			{
				count = get_count_klein(matrix_1, i, j, rows, cols);
				if (matrix_1[i][j] == 0)
				{
					if (count == 3) 
					{
						matrix_2[i][j] = 1;
					}
				} else if (matrix_1[i][j] == 1) {
					if ((count < 2) || (count > 3))
					{
						matrix_2[i][j] = 0;
					} else if ((count == 3) || (count == 2)) {
						matrix_2[i][j] = 1;
					}
				}
			}
		}
	return matrix_2;
}



/**
 * Counts the number of alive cells next to a given cell, for a klein board
 * @param the current matrix
 * @param the x coordinate (i = the rows which is the x axis)
 * @param the y coordinate (j = the cols which is the y axis)
 * @return the amount of alive cells next to the given cell (i, j)
 */
int get_count_klein(unsigned char ** matrix, int i, int j, int rows, int cols)
{
	int count = 0;
	int k;
	int l;
	int twist;

	for (k = (i - 1); k <= (i + 1); k++)
	{
		for (l = (j - 1); l <= (j + 1); l++) 
		{
			if ((k > (rows - 1)) || (k < 0))
			{
				twist = (cols - l);
			} else {
				twist = ((l + cols) % cols);
			}

			if (matrix[((k + rows) % rows)][twist] == 1) /*input %*/
			{
				count = count + 1;
			}
		}
	}

	if (matrix[i][j] == 1)
	{
		count = count - 1;
	}

	return count;
}


/**
 * frees all memfory malloc-ed for the grid
 * @param the grid to be freed
 */
void free_grid(unsigned char ** matrix)
{
	for (j = 0; j < i; j++)
	{
		free(matrix[j]);
	}
	free(matrix);
}





